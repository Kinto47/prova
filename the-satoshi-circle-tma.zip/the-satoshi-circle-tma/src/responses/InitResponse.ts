export interface InitResponse {
  daily_taps_limit: number;
}