
<template>
  <div class="text-center flex flex-col h-full p-10">
    <div class="text-6xl p-10"></div>
    <div class="flex-1 flex flex-col justify-center content-center">
      <div class="flex justify-center font-mono uppercase text-3xl">
        <div class="animate-bounce">
          Loading
        </div>
      </div>
    </div>
  </div>
</template>