<template>
  <div class="early-nft-page p-4">
    <h1 class="text-2xl font-bold">Early NFT</h1>
    <p class="mt-2">Esplora i tuoi NFT Early Access e scopri le loro caratteristiche uniche.</p>
    <!-- Aggiungi qui i contenuti relativi agli Early NFT -->
  </div>
</template>

<script setup>
</script>

<style scoped>
/* Aggiungi stili personalizzati per la pagina degli Early NFT, se necessario */
</style>
