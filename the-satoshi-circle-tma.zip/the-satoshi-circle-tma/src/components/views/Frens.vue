<template>
    <div class="profile-page p-4">
      <h1 class="text-2xl text-center font-bold">Referral System</h1><br><br>
      <p class="mt-2 font-mono text-center">Coming Soon</p>
      <!-- Aggiungi qui i dettagli del profilo utente -->
    </div>
  </template>
  
  <script setup>
  </script>
  