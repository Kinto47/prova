<!-- viewNFT.vue -->
<script setup>
import { ref } from 'vue';
import TonConnect from './TonConnect.vue';  // Importa il componente TonConnect

const nfts = ref([]);  // Stato per gli NFT recuperati
const loading = ref(true);  // Stato di caricamento
const error = ref(null);  // Stato per eventuali errori
const walletAddress = ref(null);  // Indirizzo del wallet collegato

// Funzione per recuperare gli NFT dal wallet
const fetchNFTs = async (address) => {
  try {
    const response = await fetch(`https://tonapi.io/v1/nft/getItems?owner=${address}`, {
      headers: {
        'Authorization': `AG37X5E2KH5M7NAAAAAP4WPJ5U22QKZFJ4OYQNSBB3EQVXJXNBDP5TAO3EFC4VICDMIDPCA`  // Inserisci la tua chiave API
      }
    });
    
    if (!response.ok) {
      throw new Error('Errore nella risposta dell\'API');
    }

    const data = await response.json();
    console.log('NFT data:', data);

    nfts.value = data.nft_items || [];
    loading.value = false;
  } catch (e) {
    console.error('Errore durante il recupero degli NFT:', e);
    error.value = 'Errore durante il caricamento degli NFT';
    loading.value = false;
  }
};

// Questa funzione viene chiamata quando il wallet è connesso
const handleWalletConnected = (address) => {
  walletAddress.value = address;
  console.log('Indirizzo del wallet ricevuto in viewNFT:', walletAddress.value);
  
  // Chiamata alla funzione che recupera gli NFT
  fetchNFTs(walletAddress.value);
};

</script>

<template>
  <div class="p-4">
    <!-- Usa il componente TonConnect e gestisci l'evento 'wallet-connected' -->
    <TonConnect @wallet-connected="handleWalletConnected" />

    <h1 class="text-2xl font-bold mb-4">I tuoi NFT</h1>

    <!-- Stato di caricamento -->
    <div v-if="loading" class="text-gray-500">
      Caricamento degli NFT in corso...
    </div>

    <!-- Stato di errore -->
    <div v-if="error" class="text-red-500">
      {{ error }}
    </div>

    <!-- Visualizzazione degli NFT -->
    <div v-if="!loading && !error" class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div v-for="nft in nfts" :key="nft.id" class="border rounded-lg p-4">
        <!-- Immagine NFT -->
        <img :src="nft.metadata.image" :alt="nft.metadata.name" class="w-full h-auto rounded mb-4" />

        <!-- Nome dell'NFT -->
        <h2 class="text-lg font-semibold mb-2">{{ nft.metadata.name }}</h2>

        <!-- Descrizione dell'NFT -->
        <p class="text-gray-600">{{ nft.metadata.description }}</p>
      </div>
    </div>

    <!-- Messaggio se non ci sono NFT -->
    <div v-if="!loading && nfts.length === 0" class="text-gray-500">
      Non ci sono NFT nel wallet collegato.
    </div>
  </div>
</template>
