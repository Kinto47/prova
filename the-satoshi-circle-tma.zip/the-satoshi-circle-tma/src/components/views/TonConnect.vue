<script setup>
import { ref, onMounted, defineEmits } from 'vue';
import TonConnect from '@tonconnect/sdk';

// Definisci l'emissione dell'evento per passare l'indirizzo del wallet al genitore
const emit = defineEmits(['wallet-connected']);

// Stato per memorizzare l'indirizzo del wallet connesso
const walletAddress = ref(null);
const tonConnect = new TonConnect({
  manifestUrl: 'https://the-satoshi-circle.github.io/the-satoshi-circle-tma/tonconnect-manifest.json', // Inserisci il tuo manifest URL
});

// Funzione per connettere il wallet tramite TonConnect
const connectWallet = async () => {
  try {
    // Utilizza il metodo `connect` al posto di `connectWallet`
    const provider = await tonConnect.connect({
      universalLink: "https://app.tonkeeper.com/ton-connect",
      bridgeUrl: "https://bridge.tonapi.io/bridge"
    });

    // Memorizza l'indirizzo del wallet connesso
    walletAddress.value = provider?.account?.address || null;
    console.log('Wallet connesso:', walletAddress.value);

    // Emetti l'indirizzo del wallet per comunicarlo al componente genitore
    emit('wallet-connected', walletAddress.value);
  } catch (error) {
    console.error('Errore durante la connessione al wallet:', error);
  }
};

// Connetti il wallet quando il componente è montato
onMounted(() => {
  connectWallet();
});
</script>

<template>
  <div>
    <h1 class="text-xl font-bold mb-4">Connessione al Wallet</h1>

    <!-- Mostra l'indirizzo del wallet se connesso -->
    <div v-if="walletAddress">
      <p class="text-green-500">Wallet connesso: {{ walletAddress }}</p>
    </div>

    <!-- Mostra un messaggio in attesa di connessione -->
    <div v-else>
      <p class="text-red-500">Connessione al wallet in corso...</p>
    </div>
  </div>
</template>
