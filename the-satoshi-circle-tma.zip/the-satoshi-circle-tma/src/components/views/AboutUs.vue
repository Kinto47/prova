<template>
  <div class="about-us-page p-4">
    <h1 class="text-2xl font-bold">Su di noi</h1>
    <p class="mt-2">Scopri di più su di noi e sulla nostra missione.</p>
    <!-- Aggiungi qui i contenuti relativi alla pagina "Su di noi" -->
  </div>
</template>

<script setup>
</script>

<style scoped>
/* Aggiungi stili personalizzati per la pagina "Su di noi", se necessario */
</style>
