<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'

import { store } from './common/store'

import Navbar from './components/common/Navbar.vue'

const router = useRouter()

const loading = ref(true);
const preventCollapse = function (event) {
  if (window.scrollY === 0) {
    window.scrollTo(0, 1);
  }
}

onMounted(async () => {
  await store.init()
  loading.value = false;
  router.push('/home');
})
</script>

<template>
  <div class="relative z-10">
    <div class="flex flex-col h-screen"> <!-- Usa h-screen per altezza del 100vh -->
      <div id="content" 
           class="flex-1 overflow-auto p-4" 
           v-on:touchstart="preventCollapse(event)">
        <router-view v-slot="{ Component }">
          <keep-alive>
            <component :is="Component" />
          </keep-alive>
        </router-view>
      </div>
      
      <!-- Navbar container with tailwind gradients -->
      <div id="navbar-container" 
           v-if="!loading" 
           class="relative p-3 bg-black">
        <!-- Gradient effect using Tailwind -->
        <div class="absolute h-10 -top-10 left-0 right-0 bg-gradient-to-b from-transparent to-black z-10"></div>
        <Navbar class="relative z-20"></Navbar>
      </div>
    </div>
  </div>
</template>
